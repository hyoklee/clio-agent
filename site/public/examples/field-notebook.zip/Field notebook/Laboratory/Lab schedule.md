---
tags: [example, laboratory]
---
# Lab schedule

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Laboratory/Laboratory overview]]
- [[Laboratory/Reference thermometer]]
