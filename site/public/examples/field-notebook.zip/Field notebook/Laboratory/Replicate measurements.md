---
tags: [example, laboratory]
---
# Replicate measurements

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Laboratory/Laboratory overview]]
- [[Laboratory/Sample custody]]
