---
tags: [field-study, review]
---
# Data quality

Before analysis, check that each observation has:

- A known sensor ID and station.
- A timestamp within ten minutes of the planned visit.
- A passing calibration result for that day.
- A recorded explanation for any exception.

Exclude readings from devices that failed the repeated reference check.
Keep timing exceptions visible rather than silently changing their timestamps.

The [[Field log]] provides the context behind each exception.
