---
tags: [field-study, observations]
---
# Field log

## Example visit: Meadow, 09:00

Sensor S-02 passed [[Calibration]] with a difference of 0.2 degrees Celsius.
The reading was taken at 09:07 because the access gate was closed.

Keep the observation and record the seven-minute delay. The [[Sampling plan]]
allows a ten-minute timing window. Mark later visits for [[Data quality]] review.

All station names, devices, and observations in this notebook are fictional.
