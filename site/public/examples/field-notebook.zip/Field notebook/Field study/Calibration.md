---
tags: [field-study, decision]
aliases: [Calibration decision]
---
# Calibration decision

## Decision

Calibrate every sensor before the first observation of the day.
Use a reference reading after the device has settled for five minutes.
Accept a difference of at most 0.3 degrees Celsius.

## If the check fails

Repeat the reference check. If it fails again, set the device aside and record
the failure in the [[Field log]]. Do not include its readings in the analysis.

See [[Sensor inventory]] for device IDs and [[Data quality]] for review rules.
