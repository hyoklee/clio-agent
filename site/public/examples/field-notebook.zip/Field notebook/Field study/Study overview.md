---
tags: [field-study, example]
aliases: [Study home]
---
# Field study

A fictional notebook for a small environmental sensor study.

## Before collecting data

- Follow the [[Sampling plan]] for stations and observation times.
- Complete [[Calibration]] before the first observation.
- Record exceptions in the [[Field log]].

## Review

Use [[Data quality]] to decide which observations are ready for analysis.
