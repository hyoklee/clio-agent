---
tags: [field-study, equipment]
---
# Sensor inventory

| Sensor | Station | Status |
| --- | --- | --- |
| S-01 | North | Available |
| S-02 | Meadow | Available |
| S-03 | Creek | Awaiting reference check |

All three devices require the daily [[Calibration]] check.
