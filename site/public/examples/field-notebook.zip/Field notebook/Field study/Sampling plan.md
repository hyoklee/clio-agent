---
tags: [field-study, protocol]
---
# Sampling plan

Visit the fictional North, Meadow, and Creek stations at 09:00 and 15:00.
Record temperature in degrees Celsius and note weather conditions.

Each visit needs a sensor ID, station, local timestamp, and calibration status.
Use the [[Sensor inventory]] to choose a device. Record skipped visits in the [[Field log]].
