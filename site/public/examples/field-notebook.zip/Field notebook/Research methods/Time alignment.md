---
tags: [example, research-methods]
---
# Time alignment

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Research methods/Methods overview]]
- [[Research methods/Instrument drift]]
