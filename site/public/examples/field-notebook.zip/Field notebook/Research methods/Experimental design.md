---
tags: [example, research-methods]
---
# Experimental design

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Research methods/Methods overview]]
- [[Research methods/Sampling uncertainty]]
