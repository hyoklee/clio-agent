---
tags: [example, research-methods]
---
# Reference standards

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Research methods/Methods overview]]
- [[Research methods/Replicates]]
