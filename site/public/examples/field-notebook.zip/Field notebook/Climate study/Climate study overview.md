---
tags: [example, climate-study]
---
# Climate study overview

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Climate study/Weather stations]]
- [[Climate study/Air temperature]]
- [[Climate study/Relative humidity]]
- [[Climate study/Solar radiation]]
- [[Climate study/Wind speed]]
- [[Climate study/Pressure sensors]]
- [[Climate study/Cloud observations]]
- [[Climate study/Heat events]]
- [[Climate study/Seasonal baseline]]
- [[Climate study/Weather checks]]
- [[Climate study/Climate analysis]]
- [[Research methods/Time alignment]]
