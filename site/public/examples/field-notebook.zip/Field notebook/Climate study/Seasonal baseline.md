---
tags: [example, climate-study]
---
# Seasonal baseline

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Climate study/Climate study overview]]
- [[Climate study/Weather checks]]
