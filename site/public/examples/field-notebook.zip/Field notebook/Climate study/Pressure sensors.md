---
tags: [example, climate-study]
---
# Pressure sensors

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Climate study/Climate study overview]]
- [[Climate study/Cloud observations]]
