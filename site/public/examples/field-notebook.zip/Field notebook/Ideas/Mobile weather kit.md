# Mobile weather kit

A fictional idea awaiting connections to the research notebook.
