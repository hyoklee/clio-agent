# Night sampling

A fictional idea awaiting connections to the research notebook.
