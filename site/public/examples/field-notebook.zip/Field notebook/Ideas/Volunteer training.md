# Volunteer training

A fictional idea awaiting connections to the research notebook.
