# Next season questions

A fictional idea awaiting connections to the research notebook.
