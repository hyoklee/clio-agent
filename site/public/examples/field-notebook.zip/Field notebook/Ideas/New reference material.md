# New reference material

A fictional idea awaiting connections to the research notebook.
