---
tags: [example, water-study]
---
# Catchment map

This is a fictional research notebook for the CLIO Knowledge source guide. All sites, observations and decisions are illustrative.

## Related notes
- [[Water study/Water study overview]]
- [[Water study/Water temperature]]
