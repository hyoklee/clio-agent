# Example vault
Fictional notes created for the CLIO Knowledge source guide.
Select the Field study folder to keep this overview outside the source.
